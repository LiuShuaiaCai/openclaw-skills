---
name: "crossref-xiaohongshu-daily"
description: |
  从 CrossRef 抓取当天发布的学术文章，进行多维度数据分析，生成图片，
  配文后自动发布到小红书。

  触发场景：
  - "帮我抓取今天的学术新文章"
  - "生成今日学术速报"
  - "今天的论文有哪些"
  - "学术动态日报"
  - "帮我做学术资讯分享"
  - "今日学术热点"
  - "最新学术论文"
  - "帮我生成小红书学术内容"
  - "发布今日学术日报到小红书"
  - "自动生成学术图文并发布"
  - "CrossRef 每日报告"
  - "安装小红书MCP"
  - "配置xhs-mcp"
---

# CrossRef 学术日报 → 小红书自动发布 Skill

> 一键完成：CrossRef 抓取 → 数据可视化 → 文案生成 → 小红书发布

---

## 工作流总览

```
Step 1  从 CrossRef 抓取当日学术文章
   ↓
Step 2  数据清洗 + 期刊信息补充（可选，依赖本地 MySQL）
   ↓
Step 3  生成 8 张多维度可视化图表（PNG）+ manifest.json
   ↓
Step 4  AI 整合 8 个维度生成 1 篇小红书文案（标题/正文/问题/标签）
   ↓
Step 5  安装 xhs-mcp → 扫码登录 → --mode combined 发布 1 篇笔记（8 图合并）
```

> 📌 每日只发 **1 篇**笔记，内容整合 8 个维度的核心发现。

---

## Step 1 — 环境检测

```powershell
# 检测 Python
python --version
# 检测关键依赖
python -c "import requests, pandas, matplotlib, seaborn, PIL; print('OK')"
```

---

## Step 2 — 运行主脚本，生成图表

```bash
# 抓取昨天数据（默认）
python scripts/main.py

# 抓取指定日期
python scripts/main.py 2026-04-19

# 指定输出目录
python scripts/main.py 2026-04-19 charts
```

**输出目录结构：**

```
charts/
└── 2026-04-19/
    ├── Top_20_JCR_Journals_by_Article_Count.png
    ├── Top_10_Publishers_by_Article_Count.png
    ├── Discipline_Distribution__Domain_Class_.png
    ├── JCR_Section_Distribution.png
    ├── CAS_Section_Distribution.png
    ├── First_Author_Country_Distribution.png
    ├── Top_20_Journals_by_Discipline_Heatmap.png
    ├── Top_20_Publisher_by_Discipline_Heatmap.png
    └── manifest.json
```

---

## Step 3 — 生成小红书文案

Agent 基于 `manifest.json` 中的统计数据，用 AI 生成高质量文案。

### 文案生成要求

**每日只生成 1 篇整合笔记**，内容涵盖 8 个维度的核心发现：

1. **风格**：不死板说教，要有趣但不失严谨，语气像在和朋友分享有趣发现
2. **角度**：以讨论口吻，**不要以教学者姿态**
3. **结构**：
   - 标题：**用 emoji + 悬念/反问式吸引点击**（如 `📚 昨天1.1万篇新论文，期刊战况如何？🏢 昨天这10家出版社占了半壁江山🔬 昨天11万篇论文都在研究什么？4 📊 昨天这些论文，Q1占了一半！🇨🇳 中科院分区和JCR分区差多大？🇨🇳 中科院分区和JCR分区差多大？🔍 期刊×学科交叉热力图，发现了啥？📈 出版社×学科：谁在哪个领域最强？`）
   - 正文（**≤ 1000 字符**，xhs-mcp `--content` 限制；段落分明，有洞察而不是堆数据）
   - 互动问题（真诚提问，引导用户留言讨论）
   - 话题标签（5-8个）
   - **数据来源**（固定放在正文最后）：`📊 数据来源：CrossRef（YYYY-MM-DD 共 N 篇）`
4. **必须抛出一个问题** 与用户互动

每种图表的侧重点：

| 图表类型 | 内容侧重 | 互动方向 |
|---------|---------|---------|
| 期刊发文榜（横向柱状） | 哪些期刊今天最活跃，有没有意外 | 你常投哪本？ |
| 出版社发文榜（柱状） | 出版社格局与学术马太效应 | 投稿看出版社名气吗？ |
| 学科分布（饼图） | 哪个方向最热，有无冷门惊喜 | 你的领域在哪？ |
| JCR/CAS 分区（饼图） | 高区间占比与现实投稿策略 | 你们单位有分区要求吗？ |
| 国家分布（饼图） | 科研地理格局，反差与趋势 | 你所在国排第几？ |
| 学科热力图 | 期刊×学科交叉的"深色格子"发现 | 发现哪个意外组合？ |

**输出文件：**
- `charts/{date}/copywriting_input.json` — AI 生成源文件
- `charts/{date}/copywriting.json` — 每图一篇（分条模式）
- `charts/{date}/copywriting_combined.json` — **每日整合版**（1篇汇总8个维度，用于 --mode combined）

### AI 生成后写入 JSON

由于直接用工具写入含中文复杂字符的 JSON 可能出现编码问题，建议两步走：

```bash
# 1. Agent 将生成的 JSON 写入源文件到工作目录
# 2. 用 Python helper 脚本安全序列化到目标路径
python scripts/write_copywriting.py charts/{date}/copywriting.json charts/{date}/copywriting_input.json
```

---

## Step 4 — 发布模式说明

**重要：每日发布 1 篇笔记，整合 8 个维度的精华数据。**
- 8 张图合并到 **1 篇**小红书笔记
- 文案整合 8 个维度的核心发现，1 条有参与感的互动问题
- 调用 `--mode combined` 模式自动合并所有图表

---

## Step 5 — 小红书发布（xhs-mcp）

### 4.1 安装 xhs-mcp

```bash
npm i -g xhs-mcp
```

### 4.2 扫码登录（弹出浏览器）

```bash
npx xhs-mcp login --timeout 120
```

执行后会：
1. 启动 Puppeteer Chromium 浏览器（非无头模式）
2. 自动打开小红书登录页面
3. **用户用小红书 App 扫码登录**（或账号密码）
4. 登录成功后 Cookie 自动保存

> ⚠️ 首次使用需先安装 Puppeteer 浏览器：
> ```bash
> npx xhs-mcp browser
> ```

### 4.3 验证登录状态

```bash
npx xhs-mcp status
```

### 4.4 登录过期 → 自动打开浏览器扫码

**发布前脚本会自动检测登录状态**：
- `loggedIn: true` → 直接发布
- `loggedIn: false` → 自动执行 `npx xhs-mcp login`，弹出浏览器等待用户扫码，扫码成功后再发布

> 无需手动操作，脚本自动处理。Cookie 有效期约 30 天，过期后发布时自动弹窗重扫。

### 5.4 发布笔记

#### 预览模式（推荐先执行）

```bash
python scripts/publish_xhs.py charts/2026-04-19/copywriting.json --mode preview
```

#### 整合发布（每日正式模式）

```bash
python scripts/publish_xhs.py charts/2026-04-19/copywriting_combined.json --mode combined --manifest charts/2026-04-19/manifest.json
```

> **推荐模式**：8 张图自动合并到 1 篇笔记，每日只发 1 篇。

#### 发布单条（调试用）

```bash
python scripts/publish_xhs.py charts/2026-04-19/copywriting.json --mode single --index 0
```

#### 批量发布（多篇发布模式，不推荐）

```bash
python scripts/publish_xhs.py charts/2026-04-19/copywriting.json --mode batch
```

### 4.5 Agent 执行发布

当脚本生成 `publish_task.md` 后，Agent 读取文件内容，依次调用 `xhs_create_note` MCP 工具：

```
title        → 笔记标题（≤20字）
desc         → 正文（含互动问题）
image_paths  → [image_path]（原始图表路径，无水印）
topics       → 话题标签列表（不含 # 号）
```

每条发布间隔 **≥ 30 秒**，避免触发小红书频率限制。

---

## 完整一键执行命令

```bash
DATE=$(date +%Y-%m-%d)  # 或手动指定: DATE=2026-04-19

# Step 1~3: 抓取 + 出图 + 统计
python scripts/main.py $DATE charts

# Step 4: 生成文案（Agent 在此步骤用 AI 生成高质量文案）
# Agent 生成 JSON → 保存到 charts/$DATE/copywriting_input.json
python scripts/write_copywriting.py charts/$DATE/copywriting.json charts/$DATE/copywriting_input.json

# Step 5: 安装 xhs-mcp（如尚未安装）
npm i -g xhs-mcp

# Step 6: 扫码登录（弹出浏览器，用户扫码）
npx xhs-mcp login --timeout 120

# Step 7: 预览确认（可选）
python scripts/publish_xhs.py charts/$DATE/copywriting_combined.json --mode preview

# Step 8: 整合发布（每日模式：8图合并为1篇）
python scripts/publish_xhs.py charts/$DATE/copywriting_combined.json --mode combined --manifest charts/$DATE/manifest.json
```

---

## 自动化调度

在 WorkBuddy 中创建自动化任务（每日 8:00 执行）：

**Automation Prompt：**
```
使用 crossref-xiaohongshu-daily skill，
执行今日学术日报的完整流程：
抓取昨天的 CrossRef 数据 → 生成图表 → 用 AI 生成小红书文案（整合8个维度为1篇）
→ 扫码登录小红书 → 用 --mode combined 模式发布1篇整合笔记到小红书。
工作目录: E:/WorkBuddyProjects
图表输出目录: E:/WorkBuddyProjects/charts
```

**调度规则：** `FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,FR;BYHOUR=8;BYMINUTE=0`

---

## 数据库配置说明

本 Skill 支持两种运行模式：

**有数据库（完整版）：**
- 连接本地 MySQL `express` 数据库
- 自动补充 JCR/CAS 分区、学科大类信息
- 支持期刊×学科热力图、分区饼图等高级图表

**无数据库（精简版）：**
- 自动跳过期刊信息补充步骤
- 仍可生成：期刊发文榜、出版社排行、国家分布
- 仅缺少 JCR/CAS 分区相关图表

数据库配置在 `scripts/main.py` 顶部 `DB_URI` 变量中修改。

---

## 踩坑经验

- CrossRef API 不传 `mailto` 参数会被限流，`main.py` 中已加入，请替换为真实邮箱
- `subjects` 字段覆盖率低，主要靠本地 `journals` 表的 `domain_class` 补充学科信息
- xhs-mcp publish CLI 的 `--media` 参数支持逗号分隔多图（绝对路径），`--title` 有 40 宽度单位限制（含emoji计双字节）
- xhs-mcp publish CLI 在 subprocess 中调用时，必须用 list 形式传参 `["node", "path\\to\\xhs-mcp.cjs", "publish", ...]`，避免 shell=True + 字符串拼接导致的参数解析问题
- xhs-mcp 的 Puppeteer 浏览器自动化可能因网络/页面加载慢超时，脚本内置自动重试（最多3次，指数退避）
- 小红书发布每条间隔建议 ≥ 30 秒，每日发布数量建议 ≤ 10 条，避免被限流
- AI 生成含中文的 JSON 时，建议通过 `write_copywriting.py` helper 脚本写入，避免直接工具写入导致编码问题
- xhs-mcp `login` 命令会弹出独立的 Puppeteer 浏览器窗口，用户在窗口内完成扫码
- 安装 xhs-mcp 后首次运行若提示缺少浏览器，运行 `npx xhs-mcp browser` 安装 Chromium
- **publish_xhs.py 已内置登录检测**：发布前自动检查 `loggedIn` 状态，未登录则自动弹出浏览器扫码，无需手动操作
- xhs-mcp `--content` 参数限制 **1000 字符**，文案正文需控制在此范围内；脚本内置自动截断保护
